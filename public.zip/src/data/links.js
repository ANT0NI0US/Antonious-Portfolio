import AwardIcon from "@/icons/AwardIcon";
import ChatIcon from "@/icons/ChatIcon";
import CheckIcon from "@/icons/CheckIcon";
import ContactIcon from "@/icons/ContactIon";
import CpuIcon from "@/icons/CpuIcon";
import MessageIcon from "@/icons/MessageIcon";
import MessageSquareIcon from "@/icons/MessageSquareIcon";
import OverViewIcon from "@/icons/OverViewIcon";
import PersonIcon from "@/icons/PersonIcon";
import ProjectIcon from "@/icons/ProjectIcon";
import UserStarIcon from "@/icons/UserStarIcon";

export const links = [
  {
    icon: OverViewIcon,
    path: "#overview",
    text: "Overview",
  },
  {
    icon: ContactIcon,
    path: "#contact",
    text: "Contact",
  },
];

export const aboutLinks = [
  {
    icon: PersonIcon,
    path: "#about",
    text: "About Me",
  },
  {
    icon: CheckIcon,
    path: "#services",
    text: "Services",
  },
  {
    icon: ProjectIcon,
    path: "#projects",
    text: "Projects",
  },
  {
    icon: CpuIcon,
    path: "#tech-skills",
    text: "Technical Skills",
  },
  {
    icon: MessageSquareIcon,
    path: "#soft-skills",
    text: "Soft Skills",
  },
  {
    icon: MessageIcon,
    path: "#testimonials",
    text: "Testimonials",
  },
  {
    icon: UserStarIcon,
    path: "#experiences",
    text: "Experiences",
  },
  {
    icon: AwardIcon,
    path: "#qualification",
    text: "Qualifications",
  },
  {
    icon: ChatIcon,
    path: "#blogs",
    text: "Blogs",
  },
];
