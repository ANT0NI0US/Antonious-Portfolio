import SocialLinks from "@/ui/SocialLinks";
import MainTitle from "./MainTitle";

export default function Connect() {
  return (
    <div className="flex w-full flex-col gap-2">
      <MainTitle title="Connect" />

      <p className="text-sm">Let’s create something extraordinary!</p>

      {/* SOCIAL LINKS */}
      <SocialLinks Size="size-8" Style="justify-start" />
    </div>
  );
}
