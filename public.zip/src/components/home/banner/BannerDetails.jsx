import SocialLinks from "@/ui/SocialLinks";
import CTAButtons from "./CTAButtons";
import Frontend from "./Frontend";

export default function BannerDetails() {
  return (
    <div className="flex h-full w-full flex-col gap-5 text-center lg:basis-3/5 lg:text-start">
      <div className="flex items-center justify-center gap-1.5 lg:mb-10! lg:items-start lg:justify-start">
        <span className="animate-glowing-text">🔴</span>
        <span>Currently Working</span>
      </div>

      <h1 className="font-Monoton text-primary text-xl font-black tracking-widest uppercase sm:text-3xl xl:text-4xl">
        Antonious Nasr
      </h1>

      <p className="text-2xl font-semibold sm:text-3xl xl:text-4xl">
        Hello 👋, I&apos;m a
      </p>

      {/* MY JOB CAREER TITLE */}
      <Frontend />

      {/* SOCIAL LINKS */}
      <SocialLinks />

      {/* CALL TO ACTION BUTTONS */}
      <CTAButtons />
    </div>
  );
}
