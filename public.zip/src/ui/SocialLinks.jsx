import { SOCIAL_LINKS } from "@/data/allSocialMediaLinks";
import Lottie from "react-lottie";

// Reusable Lottie icon component
const LottieIcon = ({
  animationData,
  Size = "size-8 sm:size-9 md:size-12",
}) => (
  <div className={`${Size}`}>
    <Lottie
      options={{
        loop: true,
        autoplay: true,
        animationData,
      }}
      height={"100%"}
      width={"100%"}
      isClickToPauseDisabled={true}
    />
  </div>
);

export default function SocialLinks({
  Size,
  Style = "justify-center lg:justify-start",
}) {
  return (
    <div className={`flex flex-wrap items-center gap-2 ${Style}`}>
      {SOCIAL_LINKS.map(({ href, label, animationData, title }) => (
        <a
          key={href}
          href={href}
          title={title}
          target="_blank"
          rel="noopener noreferrer"
          aria-label={label}
          className="bg-light rounded-md"
        >
          <LottieIcon animationData={animationData} Size={Size} />
        </a>
      ))}
    </div>
  );
}
