export default function Frontend() {
  return (
    <div className="before-content flexCenter relative mx-auto w-fit lg:mx-0">
      <span className="text-2xl font-bold tracking-[10px] uppercase mix-blend-difference xl:text-3xl">
        Frontend Developer
      </span>
    </div>
  );
}
