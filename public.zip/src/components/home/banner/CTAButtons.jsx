import { useHandleNavClick } from "@/hooks/useHandleNavClick";
import ContactIcon from "@/icons/ContactIon";
import Button from "@/ui/Button";

const mainLinks = [
  {
    to: "#contact",
    icon: ContactIcon,
    text: "Contact Me",
    btnType: "secondary",
    isInternal: true,
  },
  {
    to: "https://drive.google.com/file/d/1rswKOs_jOhu-LNOonWmudbslt2-T5YeX/view",
    icon: ContactIcon,
    text: "View CV",
    target: "_blank",
    isInternal: false,
  },
];

export default function CTAButtons() {
  const handleNavClick = useHandleNavClick();

  return (
    <div className="xs:w-[300px] xs:flex-row mx-auto flex w-full flex-col gap-3 lg:mx-0 xl:w-[350px] xl:gap-4">
      {mainLinks.map(
        ({ to, icon: Icon, text, target, btnType, isInternal }) => (
          <Button
            key={text}
            AriaLabel={text}
            title={text}
            onClick={isInternal ? () => handleNavClick(to) : undefined}
            href={isInternal ? undefined : to}
            target={target}
            variation={btnType}
          >
            <div className="flexCenter gap-2">
              <Icon />
              <span>{text}</span>
            </div>
          </Button>
        ),
      )}
    </div>
  );
}
