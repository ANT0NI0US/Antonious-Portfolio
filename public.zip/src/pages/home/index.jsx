import Spinner from "@/ui/spinner";
import { lazy, Suspense } from "react";

const Banner = lazy(() => import("@/components/home/banner"));
const About = lazy(() => import("@/components/home/about"));
const Services = lazy(() => import("@/components/home/services"));
const Projects = lazy(() => import("@/components/home/projects"));
const TechnicalSkills = lazy(() => import("@/components/home/technicalSkills"));
const SoftSkills = lazy(() => import("@/components/home/softSkills"));
const Testimonials = lazy(() => import("@/components/home/testimonials"));
const Experiences = lazy(() => import("@/components/home/experiences"));
const Qualifications = lazy(() => import("@/components/home/qualifications"));
const Blogs = lazy(() => import("@/components/home/blogs"));
const ProjectIdea = lazy(() => import("@/components/home/projectIdea"));
const ContactUs = lazy(() => import("@/components/home/contact"));

export default function Home() {
  return (
    <>
      <Suspense fallback={<Spinner />}>
        <Banner />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <About />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Services />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Projects />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <TechnicalSkills />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <SoftSkills />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Testimonials />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Experiences />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Qualifications />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <Blogs />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <ProjectIdea />
      </Suspense>

      <Suspense fallback={<Spinner />}>
        <ContactUs />
      </Suspense>
    </>
  );
}
