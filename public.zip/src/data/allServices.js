import AiIcon from "@/icons/AiIcon";
import CodeIcon from "@/icons/CodeIcon";
import CodeReviewIcon from "@/icons/CodeReviewIcon";
import ComponentsIcon from "@/icons/ComponentsIcon";
import DatabaseIcon from "@/icons/DatabaseIcon";
import HeadsetIcon from "@/icons/HeadsetIcon";
import LightBulbIcon from "@/icons/LightBulbIcon";
import NetworkIcon from "@/icons/NetworkIcon";
import OutlineViewIcon from "@/icons/OutlineViewIcon";
import ResponsiveIcon from "@/icons/ResponsiveIcon";
import SeoOptimizationIcon from "@/icons/SeoOptimizationIcon";
import ShieldUserIcon from "@/icons/ShieldUserIcon";
import ShoppingCartIcon from "@/icons/ShoppingCartIcon";
import SpeedIcon from "@/icons/SpeedIcon";

export const allServices = [
  {
    icon: CodeIcon,
    title: "Web Application Development",
    description:
      "Build dynamic and responsive web applications with React.js, Next.js, and modern UI frameworks, ensuring scalability and maintainability.",
  },
  {
    icon: ShoppingCartIcon,
    title: "E-commerce Development",
    description:
      "Develop feature-rich e-commerce platforms with seamless product browsing, cart management, and secure checkout processes.",
  },
  {
    icon: OutlineViewIcon,
    title: "UI/UX Implementation",
    description:
      "Transform Figma and Adobe XD designs into pixel-perfect, fully responsive interfaces for seamless user experiences.",
  },
  {
    icon: NetworkIcon,
    title: "State Management Solutions",
    description:
      "Implement efficient state management using Redux, React Query, and Zustand to ensure smooth performance and scalability.",
  },
  {
    icon: ComponentsIcon,
    title: "Custom Component Development",
    description:
      "Develop reusable, high-performance UI components tailored to your application’s needs with modern best practices.",
  },
  {
    icon: SpeedIcon,
    title: "Performance Optimization",
    description:
      "Optimize web applications for faster load times, improved performance, and a seamless user experience.",
  },
  {
    icon: ResponsiveIcon,
    title: "Cross-Platform Responsive Design",
    description:
      "Ensure flawless experiences across desktops, tablets, and mobile devices with fully responsive and adaptive designs.",
  },
  {
    icon: DatabaseIcon,
    title: "Backend Integration & API Handling",
    description:
      "Integrate robust backend services and RESTful APIs for smooth data flow and functionality in your applications.",
  },
  {
    icon: LightBulbIcon,
    title: "Technical Consulting",
    description:
      "Get expert guidance on adopting modern frontend technologies and best practices for your projects.",
  },
  {
    icon: CodeReviewIcon,
    title: "Clean Code Architecture",
    description:
      "Deliver well-structured, maintainable, and scalable codebases following industry standards and clean code principles.",
  },
  {
    icon: ShieldUserIcon,
    title: "User Experience Enhancements",
    description:
      "Focus on intuitive, user-centered design to ensure smooth interactions and high user satisfaction across all platforms.",
  },
  {
    icon: HeadsetIcon,
    title: "Fast & Reliable Support",
    description:
      "Provide quick response times, continuous assistance, and dedicated support to keep your project running smoothly.",
  },
  {
    icon: SeoOptimizationIcon,
    title: "SEO Optimization",
    description:
      "Enhance your website’s visibility on search engines with on-page SEO, performance improvements, and best practices to drive organic traffic.",
  },
  {
    icon: AiIcon,
    title: "AI Integration",
    description:
      "Add smart AI features like chatbots, recommendations, and automation to your web apps using OpenAI, TensorFlow, or custom ML models.",
  },
];
