import Icon from "@/ui/Icon";

export default function ContactIcon(props) {
  return (
    <Icon {...props}>
      <polygon points="3 11 22 2 13 21 11 13 3 11" />
    </Icon>
  );
}
