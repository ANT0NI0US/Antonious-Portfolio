import { lazy, Suspense } from "react";
import { Routes, Route, BrowserRouter } from "react-router-dom";
import Layout from "./layout";
import Spinner from "./ui/spinner";

const Home = lazy(() => import("./pages/home"));
const ExperiencesDetails = lazy(() => import("./pages/experiencesDetails"));
const Projects = lazy(() => import("./pages/projects"));
const PageNotFound = lazy(() => import("./layout/PageNotFound"));

export default function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<Home />} />
            <Route path="/experiences/:id" element={<ExperiencesDetails />} />
            <Route path="/projects/:id" element={<Projects />} />
          </Route>

          <Route path="*" element={<PageNotFound />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
